jobberwocky
===========

Java utility to run Play! Framework job outside of the web container