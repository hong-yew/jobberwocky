jobberwocky
===========

A utility to run Play! Framework job outside of the web container.

Follow this [document](jobberwocky/blob/master/documentation/manual/home.textile) for details.